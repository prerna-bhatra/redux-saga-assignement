/* eslint-disable*/

import React, { useState } from "react";
import { connect } from "react-redux";
import { loginUser } from "./redux/auth/action";

const Login = ({ dispatch, status }) => {
  console.log("action status ======> ", status);
  const [errorMessage, setErrorMessage] = React.useState("");

  const [user, setUser] = useState({
    email: "",
    password: "",
  });

  const submitLogin = () => {
    setErrorMessage("");
    dispatch(loginUser(user));
  };

  const handleChange = (value, field) => {
    setErrorMessage("");
    const temp = user;
    temp[field] = value;
    setUser({ ...temp });
  };

  const cancelLogin = () => {
    setErrorMessage("");
    const temp = user;
    temp["email"] = "";
    temp["password"] = "";

    setUser({ ...temp });
  };

  return (
    <div>
      <h3>Login</h3>

      <div>
        <p>Please use following credentilas</p>
        email : eve.holt@reqres.in, password: cityslicka
      </div>
      <br />
      <input
        type="text"
        value={user.email}
        placeholder="Email"
        onChange={(e) => handleChange(e.target.value, "email")}
      />
      <input
        type="text"
        value={user.password}
        placeholder="Password"
        onChange={(e) => handleChange(e.target.value, "password")}
      />
      <button onClick={submitLogin}>SUBMIT</button>
      <button onClick={cancelLogin}>CANCEL</button>

      <div>
        <p style={{ color: "green" }}>
          {status === "PENDING" ? "Please wait ..." : ""}
        </p>
        <p style={{ color: "red" }}>
          {status === "ERROR" ? "error occured" : ""}
        </p>
        <p style={{ color: "green" }}>
          {status === "SUCCESS" ? "Login successful" : ""}
        </p>
      </div>
    </div>
  );
};

const mapStateToProps = (state) => {
  return {
    status: state.login.status,
  };
};

export default connect(
  mapStateToProps,
  null // Generaly its the place of mapStateToDispatch
)(Login);
